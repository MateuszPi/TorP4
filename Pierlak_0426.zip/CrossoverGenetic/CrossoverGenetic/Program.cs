﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrossoverGenetic
{
    class Miasto
    {
        public decimal X { get; set; }
        public decimal Y { get; set; }

        public string CityName { get; set; }

        public Miasto(decimal x, decimal y, string cityName)
        {
            X = x;
            Y = y;
            CityName = cityName;
        }
    }

    class Calculations
    {
        public decimal CalculateDistances(Miasto A, Miasto B)
        {
            decimal distanceX = (decimal)Math.Pow((double)A.X - (double)B.X, 2);
            decimal distanceY = (decimal)Math.Pow((double)A.Y - (double)B.Y, 2);
            decimal result = (decimal)Math.Sqrt((double)distanceX + (double)distanceY);
            return result;
        }
    }

    class Distance
    {
        public string CityA { get; set; }
        public string CityB { get; set; }
        public decimal DistanceBetweenCities { get; set; }

        public Distance(string cityA, string cityB, decimal distanceBetweenCities)
        {
            CityA = cityA;
            CityB = cityB;
            DistanceBetweenCities = distanceBetweenCities;
        }
    }






    class Program
    {
        static void Main(string[] args)
        {
            var rand = new Random();
            List<Miasto> listaMiast = new List<Miasto>();

            for (int i = 0; i < 11; i++)
            {
                listaMiast.Add(new Miasto(rand.Next(-100, 100), rand.Next(-100, 100), Convert.ToString(i)));
            }
            foreach (var item in listaMiast)
            {
                Console.WriteLine($"{item.X} \t{item.Y} \t{item.CityName}");
            }

            Calculations calc = new Calculations();


            List<Distance> listOfDistances = new List<Distance>();

            for (int i = 0; i < listaMiast.Capacity; i++)
            {
                for (int j = i; j < listaMiast.Capacity - i ; j++)
                {
                    decimal distanceBetweenCities = calc.CalculateDistances(listaMiast[i], listaMiast[j]);
                    listOfDistances.Add(new Distance(listaMiast[i].CityName, listaMiast[j].CityName, distanceBetweenCities));
                }
            }

            foreach (var item in listOfDistances)
            {
                Console.WriteLine($"Dystans z {item.CityA} do {item.CityB} to {item.DistanceBetweenCities}");
            }



            Console.Read();
        }
    }
}
