﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace TorKartingowy
{
    class TextBoxFillers
    {
        SqlConnection con { get; set; }
        private void connectToDatabase()
        {
            con = new SqlConnection("Data Source=L-412-PC03;Initial Catalog=MPTor;Integrated Security=True");
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void FillTextBox(TextBox textBox, string table, string column, string condition)
        {
            SqlConnection con1 = new SqlConnection("Data Source=L-412-PC03;Initial Catalog=MPTor;Integrated Security=True");
            SqlCommand cmd = new SqlCommand($"SELECT * FROM PriceList WHERE ID_Price = 0", con1);
            con1.Open();
            //cmd.Parameters.AddWithValue()
            DataTable dT = new DataTable();
            SqlDataReader mR = null;
            mR = cmd.ExecuteReader();
            textBox.Text = mR["ID_Price"].ToString();
        }
    }
}
